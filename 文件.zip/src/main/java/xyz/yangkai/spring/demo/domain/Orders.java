package xyz.yangkai.spring.demo.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class Orders {
    private Integer id;
    private Integer money;
    private String goods;
    private Integer users_id;
}
