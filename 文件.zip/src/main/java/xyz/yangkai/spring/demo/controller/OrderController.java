//package xyz.yangkai.spring.demo.controller;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpHeaders;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.util.Base64Utils;
//import org.springframework.web.bind.annotation.*;
//import sun.jvm.hotspot.memory.HeapBlock;
//import xyz.yangkai.spring.demo.common.req.InsertOrderReq;
//import xyz.yangkai.spring.demo.common.req.UpdateOrderReq;
//import xyz.yangkai.spring.demo.common.req.UserReq;
//import xyz.yangkai.spring.demo.common.resp.*;
//import xyz.yangkai.spring.demo.service.OrderService;
//
//import javax.crypto.BadPaddingException;
//import javax.crypto.IllegalBlockSizeException;
//import javax.crypto.NoSuchPaddingException;
//import javax.servlet.annotation.HttpConstraint;
//import javax.servlet.http.HttpServletRequest;
//import javax.validation.Valid;
//import java.io.IOException;
//import java.io.UnsupportedEncodingException;
//import java.security.NoSuchAlgorithmException;
//import java.security.InvalidKeyException;
//import java.security.NoSuchAlgorithmException;
//import java.security.spec.InvalidKeySpecException;
//
//
//@Controller
//public class OrderController {
//
//    @Autowired
//    private OrderService orderService;
//
//
//    @PostMapping(value="/order")
//    @ResponseBody
//    public OrdersResp createOrder(@Valid @RequestBody InsertOrderReq req){
//        return orderService.getInsertOrderResp(req);
//    }
//
//    @GetMapping(value="/order/{id}")
//    @ResponseBody
//    public GetOrderResp getOrder(@PathVariable Integer id){
//        return orderService.getOrdersResp(id);
//    }
//
//    @DeleteMapping(value="/order/delete/{id}")
//    @ResponseBody
//    public DeleteOrderResp deleteOrder(@PathVariable Integer id){
//        return orderService.deleteOrder(id);
//    }
//
//    @PutMapping(value="order/update")
//    @ResponseBody
//    public UpdateOrderResp updateOrder(@Valid @RequestBody UpdateOrderReq req){
//        return orderService.updateOrder(req);
//    }
//
//    @GetMapping(value="/orders")
//    @ResponseBody
//    public Object getOrderList(){
//        return orderService.getOrders();
//    }
//
//    @GetMapping(value="/order/username/{username}")
//    @ResponseBody
//    public GetOrderResp gerOrderByName(@PathVariable String username){
//        return orderService.gerOrders(username);
//    }
//
//    @PostMapping(value="/order/username")
//    @ResponseBody
//    public GetOrderResp getOrderByNameByPost(@RequestBody UserReq req){
//        return orderService.getOrders(req);
//    }
//
//    @PostMapping(value="/order/username/headers")
//    @ResponseBody
//    public GetOrderResp getOrderByNameBySession(@RequestHeader HttpHeaders headers, @RequestBody UserReq req){
//        return orderService.getOrdersByNameHeaders(headers,req);
//    }
//
//
//
////
////    @PostMapping(value="/login")
////    @ResponseBody
////    public String login(@RequestParam("password") String password, Model model, HttpServletRequest httpServletRequest){
////
////        try {
////            byte[] encryptPassword  = RSACoder.decryptByPrivateKey(Base64Utils.decodeFromString(password),Base64Utils.decodeFromString((String) httpServletRequest.getServletContext().getAttribute("priKey")));
////            model.addAttribute("encryptPassword",password);
////            model.addAttribute("password", new String(encryptPassword,"UTF-8"));
////        } catch (NoSuchAlgorithmException e) {
////            e.printStackTrace();
////        } catch (InvalidKeySpecException e) {
////            e.printStackTrace();
////        } catch (NoSuchPaddingException e) {
////            e.printStackTrace();
////        } catch (InvalidKeyException e) {
////            e.printStackTrace();
////        } catch (BadPaddingException e) {
////            e.printStackTrace();
////        } catch (IllegalBlockSizeException e) {
////            e.printStackTrace();
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////
////        return "/password.jsp";
////    }
//
//
//}
