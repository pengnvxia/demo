//package xyz.yangkai.spring.demo.service;
//
//import org.springframework.beans.BeanUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpHeaders;
//import org.springframework.stereotype.Service;
//import xyz.yangkai.spring.demo.common.req.InsertOrderReq;
//import xyz.yangkai.spring.demo.common.req.UpdateOrderReq;
//import xyz.yangkai.spring.demo.common.req.UserReq;
//import xyz.yangkai.spring.demo.common.resp.*;
//import xyz.yangkai.spring.demo.domain.Orders;
//import xyz.yangkai.spring.demo.mapper.OrdersMapper;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Service
//public class OrderService {
//    //重载ordersmapper中的方法
//    @Autowired
//    private OrdersMapper ordersMapper;
//    public OrdersResp getInsertOrderResp(InsertOrderReq req){
//        Orders orders=new Orders();
//        BeanUtils.copyProperties(req,orders);
//        ordersMapper.save(orders);
//        OrdersResp resp=new OrdersResp();
//        resp.setStatusCode(1);
//        resp.setMsg("插入订单信息成功！");
//        return resp;
//    }
//
//    public GetOrderResp getOrdersResp(Integer id){
//        Orders orders = ordersMapper.getOrderById(id);
//        GetOrderResp getOrdersResp = new GetOrderResp();
//        BeanUtils.copyProperties(orders, getOrdersResp);
//        return getOrdersResp;
//    }
//
//    public DeleteOrderResp deleteOrder(Integer id){
//        ordersMapper.deleteOrderById(id);
//        DeleteOrderResp resp=new DeleteOrderResp();
//        resp.setStatusCode(200);
//        resp.setMsg("删除成功！");
//        return resp;
//    }
//
//    public UpdateOrderResp updateOrder(UpdateOrderReq req){
//        Orders orders=new Orders();
//        BeanUtils.copyProperties(req,orders);
//        ordersMapper.updateOrderById(orders);
//        UpdateOrderResp resp=new UpdateOrderResp();
//        resp.setStatusCode(200);
//        resp.setMsg("更新成功！");
//        return resp;
//    }
//
//    public Object getOrders(){
//        List<Orders> ordersList=ordersMapper.getOrders();
//        if(ordersList==null || ordersList.size()==0){
//            return "订单信息为空！";
//        }
//        List<GetOrdersresp> getOrdersresps=new ArrayList<GetOrdersresp>();
//        for (int i=0;i<ordersList.size();i++){
//            GetOrdersresp getOrdersresp=new GetOrdersresp();
//            BeanUtils.copyProperties(ordersList.get(i),getOrdersresp);
//            getOrdersresps.add(getOrdersresp);
//        }
//        return getOrdersresps;
//    }
//
//    public GetOrderResp gerOrders(String username){
//        Orders orders=ordersMapper.getOrdersByUserName(username);
//        GetOrderResp getOrderResp=new GetOrderResp();
//        BeanUtils.copyProperties(orders,getOrderResp);
//        return getOrderResp;
//    }
//
//    public GetOrderResp getOrders(UserReq req){
//        Orders orders=ordersMapper.getOrdersByUserName(req.getUsername().toString());
//        GetOrderResp getOrderResp=new GetOrderResp();
//        BeanUtils.copyProperties(orders,getOrderResp);
//        return getOrderResp;
//    }
//
//    public GetOrderResp getOrdersByNameHeaders(HttpHeaders headers,UserReq req){
//        System.out.println(req);
//        System.out.println();
//        Orders orders=ordersMapper.getOrdersByUserName(req.getUsername().toString());
//        GetOrderResp getOrderResp=new GetOrderResp();
//        BeanUtils.copyProperties(orders,getOrderResp);
//        return getOrderResp;
//    }
//
//
//
//
//
//
//
//}
