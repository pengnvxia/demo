//package xyz.yangkai.spring.demo.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//import xyz.yangkai.spring.demo.common.req.DemoReq;
//import xyz.yangkai.spring.demo.common.req.UpdateUserReq;
//import xyz.yangkai.spring.demo.common.req.UserReq;
//import xyz.yangkai.spring.demo.common.req.UserReqPk;
//import xyz.yangkai.spring.demo.common.resp.DemoResp;
//import xyz.yangkai.spring.demo.common.resp.PublicPrivateKey;
//import xyz.yangkai.spring.demo.common.resp.UserResp;
//import xyz.yangkai.spring.demo.service.DemoService;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.validation.Valid;
//
//@Controller
//public class DemoController {
//
//    @Autowired
//    private DemoService demoService;
//
//    /**
//     {
//        "username":"aaaaaa",
//        "password":"23123131"
//     }
//     * @param demoReq
//     * @return
//     */
////    @PostMapping(value = "/user")
////    @ResponseBody
////    public DemoResp createUser(@Valid @RequestBody DemoReq demoReq) {
////        return demoService.getDemoResp(demoReq);
////    }
////
////    @GetMapping(value="/user/{id}")
////    @ResponseBody
////    public UserResp getUserById(@PathVariable Integer id){
////        return demoService.getUserResp(id);
////    }
////
////    @GetMapping(value = "/users")
////    @ResponseBody
////    public Object getUserList(){
////        return demoService.getUserRespList();
////    }
////
////    @PutMapping(value = "/user")
////    @ResponseBody
////    public DemoResp getUserList(@Valid @RequestBody UpdateUserReq updateUserReq){
////        return demoService.getUpdateUserResp(updateUserReq);
////    }
////
////    @GetMapping(value="/publickey")
////    @ResponseBody
////    public String getppk(){
////        return demoService.getPpk();
////    }
////
////    @PostMapping(value="/reqister")
////    @ResponseBody
////    public DemoResp register(@Valid @RequestBody UserReqPk req){
////        return demoService.register(req);
////    }
//
//
//////    生成私钥和公钥存入数据库，接口供生成私钥和公钥
////    @GetMapping(value="/producePublicPrivateKey")
////    @ResponseBody
////    public DemoResp productPpk(){
////        return demoService.producePpk();
////    }
////
//
//    /**
//     * @return publicKey,version
//     */
////    提供公钥和版本号，客户端调用该接口，返回公钥和版本号
//
//    @GetMapping(value="/getPublicAndVersion")
//    public PublicPrivateKey getPublicKeyVersion(){
//        return demoService.getPublicKeyAndVersion();
//    }
//
//    /**
//     * @param UserReq
//     */
////注册，传入加密的密码，将密码解密后存入数据库中
//    @PostMapping(value="/register")
//    @ResponseBody
//    public DemoResp register(@RequestBody UserReq req){
//        return demoService.decrypyByVersion(req);
//    }
//
//    /**
//     * @param UserReq
//     * @return session
//     */
////登录，校验用户名和密码，返回session
//    @PostMapping(value="/login")
//    @ResponseBody
//    public DemoResp login(@Valid @RequestBody UserReq req,HttpServletResponse response){
//        DemoResp resp=demoService.login(req);
//        response.setHeader("session_id",resp.getSessionId());
//        DemoResp newResp=DemoResp.builder().msg(resp.getMsg()).statusCode(resp.getStatusCode()).build();
//        return newResp;
//    }
//
//    /**
//     * @param sessionId
//     * @return
//     */
////验证session，前端调用该接口验证session
//    @GetMapping(value="/verifySession")
//    @ResponseBody
//    public DemoResp verifySession(HttpServletRequest request){
//        return demoService.verifySession(request.getHeader("session_id"));
//    }
//
//    /**
//     * @param sessionId
//     * @return
//     */
////登出，登出后删除数据库中的Session
//    @GetMapping(value="/logout")
//    @ResponseBody
//    public void logout(HttpServletRequest request){
//        demoService.logout(request.getHeader("session_id"));
//    }
//}
