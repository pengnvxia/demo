package xyz.yangkai.spring.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xyz.yangkai.spring.demo.common.req.UserReq;
import xyz.yangkai.spring.demo.common.resp.DemoResp;
import xyz.yangkai.spring.demo.common.resp.PublicPrivateKey;
import xyz.yangkai.spring.demo.domain.Ppk;
import xyz.yangkai.spring.demo.domain.Session;
import xyz.yangkai.spring.demo.domain.Users;
import xyz.yangkai.spring.demo.mapper.DemoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import xyz.yangkai.spring.demo.utils.RSAEncrypt;


import javax.servlet.http.HttpServletResponse;
import java.security.NoSuchAlgorithmException;
import java.util.*;


@Service
public class DemoService {
    private final static Logger logger = LoggerFactory.getLogger(DemoService.class);

    @Autowired
    private DemoMapper demoMapper;

////    创建用户
//    public DemoResp getDemoResp(DemoReq demoReq){
//        Users user= new Users();
//        BeanUtils.copyProperties(demoReq,user);
////      传的值中isdel为空时，更改值为0
//        if(user.getIsDel()==null){
//            user.setIsDel(0);
//        }
//        demoMapper.save(user);
//        DemoResp resp = new DemoResp();
////        返回
//        resp.setStatusCode(1);
//        resp.setMsg("创建用户成功");
//        return resp;
//    }
//
//    public UserResp getUserResp(Integer id){
//        Users user=demoMapper.getUserById(id);
//        UserResp userResp = new UserResp();
//        BeanUtils.copyProperties(user,userResp);
//        return userResp;
//    }
//
//    public Object getUserRespList(){
//        logger.info("杨凯测试日志");
//        List<Users> usersList = demoMapper.getUserList();
//        List<UserResp> userRespList = new ArrayList<>();
//        if(usersList==null || usersList.size()==0){
//            return "没有任何用户信息";
//        }
//        for(int i=0;i<usersList.size();i++){
//            Users user= usersList.get(i);
//            UserResp userResp = new UserResp();
//            BeanUtils.copyProperties(user,userResp);
//            userRespList.add(userResp);
//        }
//        return userRespList;
//    }
//
//    public DemoResp getUpdateUserResp(UpdateUserReq updateUserReq){
//        Users dbUser=demoMapper.getUserById(updateUserReq.getId());
//        DemoResp resp = new DemoResp();
//        if(dbUser==null){
//            resp.setStatusCode(0);
//            resp.setMsg("用户id: "+updateUserReq.getId()+" 不存在");
//            return resp;
//        }
//        Users user= new Users();
//        BeanUtils.copyProperties(updateUserReq,user);
//        demoMapper.updateUserById(user);
//        resp.setStatusCode(1);
//        resp.setMsg("修改用户id:"+ user.getId() +" 成功");
//        return resp;
//    }


//    /*
//    生成公钥私钥存入数据库
//     */
//    public DemoResp producePpk(){
//        Map<Integer, String> keyMap = new HashMap<Integer, String>();
//        try {
//            keyMap=RSAEncrypt.genKeyPair();
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        }
//        Integer oldVersion=demoMapper.getVersion();
//        Ppk publicPrivateKey=new Ppk();
//        publicPrivateKey.setPublic_key(keyMap.get(0));
//        publicPrivateKey.setPrivate_key(keyMap.get(1));
//        publicPrivateKey.setVersion(oldVersion+1);
//        demoMapper.savePpk(publicPrivateKey);
//        return DemoResp.builder().msg("私钥公钥生成成功！").statusCode(200).build();
//    }
//
//    /*
//    提供公钥和版本号
//    */
//    public PublicPrivateKey getPublicKeyAndVersion(){
//        Ppk publicPrivateKey=demoMapper.getPublicPrivateKey();
//        PublicPrivateKey resp=new PublicPrivateKey();
//        resp.setPublicKey(publicPrivateKey.getPublic_key());
//        resp.setVersion(publicPrivateKey.getVersion());
//        return resp;
//    }
//
//    /*
//    根据版本号解密
//     */
//    public DemoResp decrypyByVersion(UserReq req){
//        if(demoMapper.getUserByUserName()>0){
//            return DemoResp.builder().msg("用户名已经存在，请重新输入！").statusCode(100).build();
//        }
//        Integer version=req.getVersion();
//        String privateKey=new String();
//        if(version==null || "".equals(version)){
//            privateKey = demoMapper.getPrivateKeyByVersion(0).getPrivate_key();
//        }else {
//            privateKey=demoMapper.getPrivateKeyByVersion(version).getPrivate_key();
//        }
//        String password = null;
//        try {
//            password=RSAEncrypt.decrypt(req.getPassword(),privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        Users user= new Users();
//        user.setUsername(req.getUsername());
//        user.setPassword(password);
//        user.setIsDel(0);
//        demoMapper.save(user);
//        DemoResp resp=DemoResp.builder().msg("注册成功").statusCode(200).build();
//        return resp;
//
//    }
//    /*
//    校验session,返回用户id
//     */
//    public DemoResp verifySession(String sessionId){
//        Users users=demoMapper.getUserBySessionId(sessionId);
//        if(users==null){
//            return DemoResp.builder().msg("登录过期，请重新登录！").statusCode(100).build();
//        }
//        return DemoResp.builder().userId(users.getId()).build();
//    }
//
//
//    /*
//     登录，返回sessionid
//     */
//    public DemoResp login(UserReq userReq){
//        Integer version=userReq.getVersion();
//        String privateKey=new String();
//        if(version==null || "".equals(version)){
//            privateKey = demoMapper.getPrivateKeyByVersion(0).getPrivate_key();
//        }else {
//            privateKey=demoMapper.getPrivateKeyByVersion(version).getPrivate_key();
//        }
//        String password = null;
//        try {
//            password=RSAEncrypt.decrypt(userReq.getPassword(),privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        Users users=Users.builder().username(userReq.getUsername()).password(password).build();
//        //验证用户名密码是否存在
//        Users userInfo=demoMapper.getUserByUsernameAndPassword(users);
//        if(userInfo==null){
//            return DemoResp.builder().msg("用户名或密码错误，请重新输入！").statusCode(100).build();
//        }
//        String sessionId=generateSessionId(userInfo.getId());
//        return DemoResp.builder().msg("登录成功！").statusCode(200).sessionId(sessionId).build();
//    }
//
//    /*
//    登出
//     */
//    public void logout(String sessionId){
//        if(sessionId!=null || !("".equals(sessionId))){
//            demoMapper.deleteSession(sessionId);
//        }
//    }
//
//    /*
//    生成sessionId
//     */
//    public String generateSessionId(Integer id){
//        String sessionId= UUID.randomUUID().toString();
//        Session session=new Session();
//        session.setUser_id(id);
//        session.setSession_id(sessionId);
//        demoMapper.saveSession(session);
//        return sessionId;
//    }

}
