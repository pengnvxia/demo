package xyz.yangkai.spring.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import xyz.yangkai.spring.demo.domain.Ppk;
import xyz.yangkai.spring.demo.domain.Session;
import xyz.yangkai.spring.demo.domain.Users;

import java.util.List;


//与demomapper.xml关联，上接service下接xml文件
@Mapper
public interface DemoMapper {
//    demomapper.xml中的id方法转换为这边的一个方法
//    void save(Users users);
//
////    Users getUserById(@Param(value="id") Integer id);
////
////    void updateUserById(Users users);
////
////    List<Users> getUserList();
//    void savePpk(Ppk ppk);
////    Integer getByPublicKey(String publicKey);
////    String getPrivateKeyByPublicKey(String public_key);
//    Ppk getPublicPrivateKey();
//    Ppk getPrivateKeyByVersion(Integer version);
//    Integer getVersion();
//    Integer getUserByUserName();
//    Users getUserByUsernameAndPassword(Users users);
//    void saveSession(Session session);
//    Users getUserBySessionId(String session_id);
//    void deleteSession(String session_id);
}
