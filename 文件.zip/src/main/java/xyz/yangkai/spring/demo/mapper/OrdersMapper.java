//package xyz.yangkai.spring.demo.mapper;
//import org.apache.ibatis.annotations.Mapper;
//import org.apache.ibatis.annotations.Param;
//import xyz.yangkai.spring.demo.domain.Orders;
//import java.util.List;
//
//@Mapper
//public interface OrdersMapper {
//    void save(Orders orders);
//    Orders getOrderById(@Param(value="id") Integer id);
//    void deleteOrderById(@Param(value="id") Integer id);
//    void updateOrderById(Orders orders);
//    List<Orders> getOrders();
//    Orders getOrdersByUserName(@Param(value="username") String username);
//}
